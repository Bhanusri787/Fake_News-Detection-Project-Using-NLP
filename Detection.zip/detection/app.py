from flask import Flask, render_template, request
import pickle
import os

app = Flask(__name__)

# Load the trained model
MODEL_FILE = "model.pkl"
VECTORIZER_FILE = "vectorizer.pkl"

if not os.path.exists(MODEL_FILE):
    raise FileNotFoundError(f"Model file '{MODEL_FILE}' not found. Train and save the model first.")
if not os.path.exists(VECTORIZER_FILE):
    raise FileNotFoundError(f"Vectorizer file '{VECTORIZER_FILE}' not found. Train and save it first.")

# Load model
with open(MODEL_FILE, 'rb') as model_file:
    loaded_model = pickle.load(model_file)

# Load TF-IDF vectorizer (must be the same as in training)
with open(VECTORIZER_FILE, 'rb') as vectorizer_file:
    tfvect = pickle.load(vectorizer_file)

# Fake news detection function
def fake_news_det(news):
    vectorized_input_data = tfvect.transform([news])  # Use transform(), not fit()
    prediction = loaded_model.predict(vectorized_input_data)[0]  # Extract first element
    return prediction

@app.route('/')
def home():
    return render_template('index.html', prediction=None)

@app.route('/predict', methods=['POST'])
def predict():
    if request.method == 'POST':
        message = request.form['message']
        pred = fake_news_det(message)
        return render_template('index.html', prediction=pred, message=message)
    return render_template('index.html', prediction="Something went wrong")

if __name__ == '__main__':
    app.run(debug=True)
